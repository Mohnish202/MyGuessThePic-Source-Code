(function () {
    var expandProperties,
        listeners,
        placementType,
        state,
        states,
        viewable = false;

    expandProperties = {
        useCustomClose:false,
        isModal:true,
        useCustomSwipe:false,
        ignoreSwipe:false,
        x:0,
        y:0
    };

    states = ["loading", "hidden", "default", "expanded"];
    placementType = "inline";
    state = "loading";
    viewable = true;
    listeners = {};

    this.mraid = {
        sendJSErrorMessage:function (message) {
            adServerMRAIDbridge.sendJSErrorMessage(message);
        },
        logEntry:function (message) {
            adServerMRAIDbridge.logEntry(message);
        },
        getVersion:function () {
            return adServerMRAIDbridge.getVersion();
        },
        getState:function () {
            return state;
        },
        isViewable:function () {
            return viewable;
        },
        close:function () {
            return adServerMRAIDbridge.close();
        },
        open:function (url) {
            return adServerMRAIDbridge.open(url);
        },
        expand:function () {
            var url;
            url = 1 <= arguments.length ? Array.prototype.splice.call(arguments, 0) : [];
            if ((url != null ? url.length : 0) === 0) {
                return adServerMRAIDbridge.expand();
            } else {
                return adServerMRAIDbridge.expand(url[0]);
            }
        },
        getPlacementType:function () {
            return placementType;
        },

        getExpandProperties:function () {
            return expandProperties;
        },
        setExpandProperties:function (properties) {
            this.logEntry("mraid set expandProperties: "+ JSON.stringify(properties));

            if (properties.width) {
                this.logEntry("mraid set expandProperties.width: "+ properties.width);
                expandProperties.width = properties.width;
            }
            if (properties.height) {
                this.logEntry("mraid set expandProperties.height: "+ properties.height);
                expandProperties.height = properties.height;
            }
            if (properties.ignoreSwipe) {
                this.logEntry("mraid set expandProperties.ignoreSwipe: "+ properties.ignoreSwipe);
                expandProperties.ignoreSwipe = properties.ignoreSwipe;
            }
            if (properties.useCustomClose) {
                this.logEntry("mraid set expandProperties.useCustomClose: "+ properties.useCustomClose);
                expandProperties.useCustomClose = properties.useCustomClose;
            }
            if (properties.x) {
                this.logEntry("mraid set expandProperties.x: "+ properties.x);
                expandProperties.x = properties.x;
            }
            if (properties.y) {
                this.logEntry("mraid set expandProperties.y: "+ properties.y);
                expandProperties.y = properties.y;
            }
            if (typeof properties.isModal != 'undefined') {
                this.logEntry("mraid set expandProperties.isModal: "+ properties.isModal);
                expandProperties.isModal = properties.isModal;
            }
            return adServerMRAIDbridge.setExpandProperties(JSON.stringify(expandProperties));
        },
        useCustomClose:function (useCustomClose) {
            this.logEntry("mraid set useCustomClose(): "+ useCustomClose);
            expandProperties.useCustomClose = useCustomClose;
            return adServerMRAIDbridge.setExpandProperties(JSON.stringify(expandProperties));
        },
        addEventListener:function (event, listener) {
            if (event === "ready" || event === "stateChange" || event === "viewableChange" || event === "error") {
                return (listeners[event] || (listeners[event] = [])).push(listener);
            }
        },
        removeEventListener:function () {
            var event, l, listener;
            event = arguments[0], listener = 2 <= arguments.length ? Array.prototype.slice.call(arguments, 1) : [];
            if (listeners[event] && listener.length > 0) {
                return listeners[event] = (function () {
                    var i, len, ref, results;
                    ref = listeners[event];
                    results = [];
                    for (i = 0, len = ref.length; i < len; i++) {
                        l = ref[i];
                        if (l !== listener[0]) results.push(l);
                    }
                    return results;
                })();
            } else {
                return delete listeners[event];
            }
        },
        fireImpressions:function (){
            adServerMRAIDbridge.fireImpressions();
        },
        fireClicks:function (){
            adServerMRAIDbridge.fireClicks();
        },
        fireEvent:function (event) {
            var listener, i, len, ref, results;
            this.logEntry("JS: fired " + event);
            if (listeners[event]) {
                ref = listeners[event];
                results = [];
                for (i = 0, len = ref.length; i < len; i++) {
                    listener = ref[i];
                    if (event === "ready") listener();
                    if (event === "stateChange") listener(state);
                    if (event === "viewableChange") {
                        results.push(listener(viewable));
                    } else {
                        results.push(void 0);
                    }
                }
                return results;
            }
        },
        fireErrorEvent:function (message, action) {
            var listener, i, len, ref, results;
            ref = listeners["error"];
            results = [];
            for (i = 0, len = ref.length; i < len; i++) {
                listener = ref[i];
                results.push(listener(message, action));
            }
            return results;
        },
        setState:function (state_id) {
            switch (state_id) {
                case 1:
                    state = "loading";
                    break;
                case 2:
                    state = "default";
                    break;
                case 3:
                    state = "expanded";
                    break;
                case 4:
                    state = "hidden";
            }
            return mraid.fireEvent("stateChange");
        },
        setViewable:function (is_viewable) {
            viewable = is_viewable;
            return mraid.fireEvent("viewableChange");
        },
        setPlacementType:function (type) {
            adServerMRAIDBridge.setPlacementType(type);
            if (type === 0) {
                return placementType = "inline";
            } else if (type === 1) {
                return placementType = "interstitial";
            }
        },

        showNativeMessageDialog:function(title, buttons){
            adServerMRAIDbridge.showNativeMessageDialog(title,JSON.stringify(buttons));
        },

        nativeDialogCallback:function(result) {},

        getDirectFileDownload:function(){
            return adServerMRAIDbridge.getDirectFileDownload();
        },

        getInstallActionSubId:function(){
            return adServerMRAIDbridge.getInstallActionSubId();
        },

        setParamsInstallActionSubId:function(directFileDownload,installActionSubId){
            adServerMRAIDbridge.setDirectFileDownload(directFileDownload, installActionSubId);
        }

    };
}).call(this);
